int main(){
		int a1[73][73];
		int a2[73][73];
		int a73[73][73];

		int i, j, k, sum = 0;
		for(i=0;i<73;i++) {
			for(j=0;j<73;j++) {
				get(a1[i][j]);
			}
		}
		for(i=0;i<73;i++) {
			for(j=0;j<73;j++) {
				get(a2[i][j]);
			}
		}
		for (i = 0; i < 73; i++) {
			for (j = 0; j < 73; j++) {
				for (k = 0; k < 73; k++) {	
					sum = sum + a1[i][k]*a2[k][j];
				}
 
				a73[i][j] = sum;
				sum = 0;
			}
		}

		for(i=0;i<73;i++) {
			for(j=0;j<73;j++) {
				put(a73[i][j]);
			}
		}
}