int main() {
	int a;
	int b;
	a=5;
	b=3;
	b=a-(-b);
	put(b);
	b=-b;
	put(b);
}