
int main()
{
   int e=6;
   int a=0;
   int b=0;
   int c=1;
   int d=3;
   int f=0;
   int g=0;

   e=((a+b)-c+(d*g)+e)+f;

   put(e);
}