
int arr[4];
int n = 4;
int search = 22222;

int bs() {
 int first, last, middle;
 first = 0;
 last = n - 1;
 middle = (first+last)/2;

 while(first <= last) {
		if(arr[middle] < search)
			 first = middle + 1;
		else if (arr[middle] == search) {
			 return (middle+1);
		}
		else {
			 last = middle - 1;
		}
	middle = (first + last)/2;
 }
 return 0;
}

int main()
{
 n = 4;
 arr[0] = 10;
 arr[1] = 20;
 arr[2] = 30;
 arr[3] = 40;
 search = 10;
 int t = bs();
 put(t);
}
