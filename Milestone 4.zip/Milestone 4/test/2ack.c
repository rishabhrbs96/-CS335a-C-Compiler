int count = 0;
int indent = 0;

int ackermann(int x, int y) {
	int p, t;
	count++;
	if(x<0 || y<0){
		t = -1;
	}
	else if(x==0){
		t = y+1;
	}
	else if(y==0)
		t = ackermann(x-1,1);
	else{
		p = ackermann(x,y-1);
		t = ackermann(x-1,p);
	}
	return t;
}

int main()
{
	int x;
	int y;
	x=3;
	y=5;
	put(x);
	put(y);
	put(ackermann(x,y));
}