int f()

int main() {
  int a, c;
  f(2.4,1);
  return 0;
}