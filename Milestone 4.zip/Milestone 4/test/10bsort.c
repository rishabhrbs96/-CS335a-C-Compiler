int array[5];
int n = 5, c = 0, d = 0, swap;

void sort() {
 int t = n-1;
  for(; c < t; c++) {
    for(; d < t - c; d++) {
      if(array[d] > array[d+1]) {
        swap       = array[d];
        array[d]   = array[d+1];
        array[d+1] = swap;
      }
    }
  }
}

int main()
{
  
  array[0] = 5;
  array[1] = 3;
  array[2] = 123;
  array[3] = 3;
  array[4] = 412;
  
  for( c = 0 ; c < n ; c++ )
     put(array[c]);
 

}